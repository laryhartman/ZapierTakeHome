# ZapierTakeHome
Take home assignment from Zapier for Customer Churn Calculation.
